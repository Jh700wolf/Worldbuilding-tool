#ifndef PERSONAJE_H_
#define PERSONAJE_H_

#include <iostream>
#include <String>
#include <Vector>
#include <sstream>

using namespace std;

class personaje{
    protected:
        string nombre;
        string descripcion;
        string biografia;
};



#endif