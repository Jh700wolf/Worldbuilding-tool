#include <iostream>
#include "Mundo.cpp"

using namespace std;

void menu(){
    cout << "1. Añadir evento" << endl;
    cout << "2. Añadir lugar" << endl;
    cout << "3. Añadir Personaje" << endl;
    cout << "4. Cambiar nombre del mundo" << endl;
    cout << "5. Cambiar descripcion" << endl;
    cout << "6. Ver mundo" << endl;
    cout << "7. Salir" << endl;
    cout << endl;
}
int main()
{
    cout << "Bienvenido al creador de Mundos" << endl;
    bool continuar = true;
    string _nombre;
    string _descripcion;
    cout << "Dame el nombre del mundo" << endl;
    cin >> _nombre;
    cout << "Dame una pequeña descripción del mundo" << endl;
    cin >> _descripcion;
    mundo nuevoMundo (_nombre,_descripcion);
    cout << nuevoMundo.get_mundoInfo();
    cout << endl;
    while (continuar == true)
    {
        cout << "Eliga algo a agregar" << endl;
        menu();
        cout << "Opcion : " << endl;
        int eleccion;
        cin >> eleccion;
        if(eleccion == 1){
            string _nombree;
            string _fechae;
            string _descripcione;

            cout << "Dame el nombre del evento: " << endl;
            cin >> _nombree;
            cout << "Dame la fecha para este evento: " << endl;
            cin >> _fechae;
            cout << "Que sucedio en este evento? " << endl;
            cin >> _descripcione;
            evento eventoNuevo(_nombree,_fechae,_descripcione);
            nuevoMundo.añadirEvento(eventoNuevo);
            cout << eventoNuevo.get_eventoInfo();
        }
        else if (eleccion == 2){
            string _nombreL;
            string _descripcionL;
            cout << "Dame el nombre del lugar: " << endl;
            cin >> _nombreL;
            cout << "Describe el lugar: " << endl;
            cin >> _descripcionL;
            lugar lugarNuevo(_nombreL,_descripcionL);
            nuevoMundo.añadirLugar(lugarNuevo);
            cout << lugarNuevo.get_lugarInfo();
        }
        else if (eleccion == 3){
            string _nombreP;
            string _descripcionP;
            string _biografiaP;
            int elecJugador;
            cout << "Dame el nombre del personaje: " << endl;
            cin >> _nombreP;
            cout << "Describe el personaje: " << endl;
            cin >> _descripcionP;
            cout << "Describe su vida hasta ahora: " << endl;
            cin >> _biografiaP;
            cout << "Es un jugaor o un NPC/Personaje de novela? 1. Jugador 2.NPC";
            cin >> elecJugador;

            if (elecJugador == 1){
                string _nombreJP;
                string _claseJugador;
                cout << "Quien juega a este personaje? " << endl;
                cin >> _nombreJP;
                cout << "Que clase eligio? " << endl;
                cin >> _claseJugador;
                jugador nuevoPersonajeJ(_nombreP, _nombreJP, _claseJugador, _descripcionP, _biografiaP);
                nuevoMundo.añadirJugador(nuevoPersonajeJ);
                nuevoPersonajeJ.get_jugadorInfo();
            }
                else if (elecJugador == 2){
                string _notas;
                cout << "Algo relevante para tu historia? " << endl;
                cin >> _notas;
                noJugador nuevoPersonajeNJ(_nombreP, _notas, _descripcionP, _biografiaP); 
                nuevoMundo.añadirPersonaje(nuevoPersonajeNJ);
                nuevoPersonajeNJ.get_njInfo();
        }

        else if (eleccion == 4){
            string nuevoNombre;
            nuevoMundo.set_nombre(nuevoNombre);
        }

        else if (eleccion == 5){
            string nuevaDescripcion;
            nuevoMundo.set_descripcion(nuevaDescripcion);
        }
        else if (eleccion == 6){
            cout << "Asi se ve tu mundo actualmente:" << endl;
            cout << nuevoMundo.get_mundoInfo();
        }
        else if (eleccion == 7){
            continuar = false;
        }
    
    }

    
    return 0;
}